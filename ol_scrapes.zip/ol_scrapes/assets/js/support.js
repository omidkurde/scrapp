(function($) {

    var allPanels = $('.scrapes-accordion > .scrapes-accordion-content');
    $('.scrapes-accordion>.scrapes-accordion-content.active').show();

    $('.scrapes-accordion > .scrapes-accordion-trigger > a').click(function() {
        $this = $(this);
        $target =  $this.parent().next();
        
        if(!$target.hasClass('active')){
            allPanels.removeClass('active').slideUp();
            $target.addClass('active').slideDown();
            $('.scrapes-accordion > .scrapes-accordion-trigger > a').removeClass('active')
            $this.addClass('active');
        } else {
            $this.removeClass('active');
            $target.removeClass('active').slideUp();
        }
    return false;
    });

})(jQuery);