"use strict";
function puppeteerDelay(time) {
   return new Promise(function(resolve) { 
       setTimeout(resolve, time)
   });
}
const puppeteer = require('puppeteer');
(async () => {
  var args = process.argv.slice(2);
  process.on('unhandledRejection', up => { throw up })
  var argarr = ['--no-sandbox', '--disable-setuid-sandbox'];
  if(args[1] !== undefined && args[1] !== 'null')
  {
      argarr.push("--proxy-server=" + args[1]);
  }
  if(args[2] != 'default')
  {
      argarr.push("--user-agent=" + args[2]);
  }
  const browser = await puppeteer.launch({args: argarr});
  const page = await browser.newPage();
  if(args[3] != 'default')
  {
      var kkarr = args[3].split(';');
      kkarr.forEach(async function (value) 
      {
          var cookiesobje = '';
          var splitCookie = value.split('=');
          try {
              cookiesobje += '{"name": "' + splitCookie[0].trim() + '","value": "' + decodeURIComponent(splitCookie[1]) + '", "url": "' + args[0] + '"}';
          } catch (error) {
              cookiesobje += '{"name": "' + splitCookie[0].trim() + '","value": "' + splitCookie[1] + '", "url": "' + args[0] + '"}';
          }
          var cookiesobjex = JSON.parse(cookiesobje);
          await page.setCookie(cookiesobjex);
            
      });
  }
  if(args[4] != 'default')
  {
      var xres = args[4].split(":");
      if(xres[1] != undefined)
      {
          var user = xres[0];
          var pass = xres[1];
          const auth = new Buffer(`${user}:${pass}`).toString('base64');
          await page.setExtraHTTPHeaders({
              'Authorization': `Basic ${auth}`                    
          });
      }
  }
  if(args[5] != 'default')
  {
      await page.setDefaultNavigationTimeout(args[5]);
  }
  await page.goto(args[0], {waitUntil: 'networkidle2'});
  const bodyWidth = await page.evaluate(() => document.body.scrollWidth);
  const bodyHeight = await page.evaluate(() => document.body.scrollHeight);
  await page.setViewport({ width: bodyWidth, height: bodyHeight });
  if(args[6] != 'default' && args[6] != '' && args[6] != '0')
  {
      await puppeteerDelay(args[6]);
  }
  let bodyHTML = await page.content();
  console.log(bodyHTML);
  await browser.close();
})();