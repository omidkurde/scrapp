<?php

/** no direct access **/
if (!defined('ABSPATH'))
	exit;

foreach ($post_meta_name_values as $key => $value) 
{
	if (stripos($value, "//") === 0) {
		$node = $xpath->query($value);
		if( !empty($post_meta_get_json[$post_meta_index]) ) 
		{
			$node = $this->requir_fn->scrape_json_from_body($body_json, $value);
		}
		if ($node->length) {
			$node = $node->item(0);
			$ts_tab_custom_field = '';
			if(class_exists('TS_Options')) {
				$option_ts = (get_option('ts_page_settings_is_active',true));
				$ts_tab_custom_field = array_key_exists("ts_active_custom_field", $option_ts) ? $option_ts['ts_active_custom_field'] : '';
			}
			if (!empty($post_meta_allowhtmls[$post_meta_index]) || $key == '_ts_meta_size' ||  $key == '_ts_meta_color' || $key == '_ts_meta_custom' || $key == $ts_tab_custom_field) {
				$value = $node->ownerDocument->saveXML($node);
				$value = $this->image_fn->convert_html_links($value, $url, $html_base_url);
			} else {
				if (!empty($post_meta_attributes[$post_meta_index])) 
				{										
					if( !empty($post_meta_get_json[$post_meta_index]) ) 
					{
						$value = $this->requir_fn->get_value_from_json($node->nodeValue, $post_meta_attributes[$post_meta_index]);
					} else {
						$value = $node->getAttribute($post_meta_attributes[$post_meta_index]);
					}
					if( !empty($post_meta_downloads[$post_meta_index]) )
					{
						$meta_downloads[$key] = $value;
					}
				} else {
					$value = $node->nodeValue;
				}
			}
			if(function_exists('convert_to_english')){
				if(!empty('_price') || !empty('_sale_price') || !empty('_regular_price') || !empty('_stock')) {
					if($option_ts['ts_active_persian_price'] != 'off'){
						$value = convert_to_english($value);
					}
				}
			}						
			
			if( is_array($value) ) {
				$this->write_log($value);
			} else {
				$this->write_log("post meta $key : " . (string)$value);
			}
			if ($enable_spin) {
				$value = $this->spin_content_with_thebestspinner($spin_email, $spin_password, $value);
			}
			if ($enable_translate) {
				if (class_exists('TS_Translate')) {
					$chk_section = !empty($meta_vals['scrape_translate_fields'][0]);
					$section_type = isset($meta_vals['scrape_translate_sections'][0]) ? $meta_vals['scrape_translate_sections'][0] : 'all_sections';					
					
					if($chk_section || $section_type == 'all_sections')
					{
						$value = TS_Translate::translate($source_language, $target_language, $value);
						$value = $this->ordered_html_tag($value);
					}
				}
			}
			
			if (!empty($post_meta_regex_statuses[$post_meta_index])) {
				
				$regex_combined = array_combine($post_meta_regex_finds[$post_meta_index], $post_meta_regex_replaces[$post_meta_index]);
				foreach ($regex_combined as $find => $replace) {
					$this->write_log("custom field value before regex $value");
					$value = preg_replace("/" . str_replace("/", "\/", $find) . "/isu", $replace, $value);
					$this->write_log("custom field value after regex $value");
				}
			}
		} else {
			$this->write_log("post meta $key : found empty.", true);
			$this->write_log("URL: " . $url . " XPath: " . $value . " returned empty for post meta $key", true);
			$value = '';
		}
	}
	
	if ($woo_active && $post_type == 'product') {
		if (in_array($key, $woo_price_metas)) {
			$value = $this->convert_str_to_woo_decimal($value);
		}
		if (in_array($key, $woo_decimal_metas)) {
			$value = floatval($value);
		}
		if (in_array($key, $woo_integer_metas)) {
			$value = intval($value);
		}
	}
	
	if (!empty($post_meta_template_statuses[$post_meta_index])) {
		$template_value = $post_meta_templates[$post_meta_index];
		$affiliate = $url;
		if( preg_match("/(\/|\.)digikala\./", $url) ) {
			//$affiliate = $this->scrape_url_shorten($url);
		}
		$affiliate = base64_encode($affiliate);
		$affiliate = str_replace(array('+','/','='),array('-','_',''),$affiliate);
		$value = str_replace("[scrape_value]", $value, $template_value);
		if(class_exists('TS_Options')) {
			if(function_exists('wp_date')) {					
				$value = str_replace("[scrape_date]", $save_post_date_jalali, $value);
			}
		} else {
			$value = str_replace("[scrape_date]", $post_date, $value);
		}
		$value = str_replace("[scrape_url]", $url, $value);
		$value = str_replace("[affiliate]", $affiliate, $value);
		
		preg_match_all('/\[scrape_meta name="([^"]*)"\]/', $value, $matches);
		
		$full_matches = $matches[0];
		$name_matches = $matches[1];
		if (!empty($full_matches)) {
			$combined = array_combine($name_matches, $full_matches);
			
			foreach ($combined as $meta_name => $template_string) {
				$val = $meta_input[$meta_name];
				$value = str_replace($template_string, $val, $value);
			}
		}
		
		if (preg_match('/calc\((.*)\)/isu', $value, $matches)) {
			$full_text = $matches[0];
			$text = $matches[1];
			$calculated = $this->template_calculator($text);
			$value = str_replace($full_text, $calculated, $value);
		}
		
		if (preg_match('/\/([a-zA-Z0-9]{10})(?:[\/?]|$)/', $url, $matches)) {
			$value = str_replace("[scrape_asin]", $matches[1], $value);
		}
		
	}
	
	if ($woo_active && $post_type == 'product') {
		if (in_array($key, $woo_price_metas)) {

			if(!empty($meta_vals['scrape_rounding_enable'][0])) {
				
				$value = $this->requir_fn->scrape_round_price($value, $meta_vals['scrape_rounding_price'][0], $meta_vals['scrape_rounding_type'][0], $meta_vals['scrape_rounding_side'][0]);
			}
		}
	}	
	
	$meta_input[$key] = $value;
	$post_meta_index++;
	
	if( !is_array($value) ) {
		$this->write_log("final meta for " . $key . " is " . $value);
	}
}