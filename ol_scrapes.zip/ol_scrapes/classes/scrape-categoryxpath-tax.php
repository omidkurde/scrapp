<?php

/** no direct access **/
if (!defined('ABSPATH'))
	exit;

foreach($post_tax_name_values as $tax_name => $tax_value) {
	$node = $xpath->query($tax_value);
	if ($node->length) {
		if ($node->length > 1) {
			$post_cat = array();
			foreach ($node as $item) {
				$orig = trim($item->nodeValue);
				if ($enable_spin) {
					$orig =  $this->requir_fn->spin_content_with_thebestspinner($spin_email, $spin_password, $orig);
				}
				if ($enable_translate) {
					if (class_exists('TS_Translate')) {
						$chk_section = !empty($meta_vals['scrape_translate_taxonomy'][0]);
						$section_type = isset($meta_vals['scrape_translate_sections'][0]) ? $meta_vals['scrape_translate_sections'][0] : 'all_sections';										
						
						if($chk_section || $section_type == 'all_sections') {
							$orig = TS_Translate::translate($source_language, $target_language, $orig);
						}
					}
				}
				if (!empty($post_tax_regex_statuses[$post_meta_index])) {
					$combined = array_combine($post_tax_regex_finds[$post_meta_index], $post_tax_regex_replaces[$post_meta_index]);
					foreach ($combined as $regex => $replace) {
						$this->write_log('category before regex: ' . $orig);
						$orig = preg_replace("/" . str_replace("/", "\/", $regex) . "/isu", $replace, $orig);
						$this->write_log('category after regex: ' . $orig);
					}
				}
				$post_cat[] = $orig;
			}
		} else {
			$post_cat = $node->item(0)->nodeValue;
			if ($enable_spin) {
				$post_cat = $this->requir_fn->spin_content_with_thebestspinner($spin_email, $spin_password, $post_cat);
			}
			if ($enable_translate) {
				if (class_exists('TS_Translate')) {
					$chk_section = !empty($meta_vals['scrape_translate_taxonomy'][0]);
					$section_type = isset($meta_vals['scrape_translate_sections'][0]) ? $meta_vals['scrape_translate_sections'][0] : 'all_sections';										
						
					if($chk_section || $section_type == 'all_sections') {									
						$post_cat = TS_Translate::translate($source_language, $target_language, $post_cat);
					}
				}
			}
			if (!empty($post_tax_regex_statuses[$post_meta_index])) {
				$combined = array_combine($post_tax_regex_finds[$post_meta_index], $post_tax_regex_replaces[$post_meta_index]);
				foreach ($combined as $regex => $replace) {
					$this->write_log('category before regex: ' . $post_cat);
					$post_cat = preg_replace("/" . str_replace("/", "\/", $regex) . "/isu", $replace, $post_cat);
					$this->write_log('category after regex: ' . $post_cat);
				}								
			}
		}
		if (!empty($post_tax_template_statuses[$post_meta_index])) {
			$template_value = $post_tax_templates[$post_meta_index];
			$post_cat = str_replace("[scrape_value]", $post_cat, $template_value);		
		}						
		$this->write_log("category : ");
		$this->write_log($post_cat);
		
		$cat_separator = $post_tax_separator[$post_meta_index];
		
		if (!is_array($post_cat) || count($post_cat) == 0) {
			if ($cat_separator != "") {
				$post_cat = str_replace("\xc2\xa0", ' ', $post_cat);
				$post_cats = explode($cat_separator, $post_cat);
				$post_cats = array_map("trim", $post_cats);
			} else {
				$post_cats = array($post_cat);
			}
		} else {
			$post_cats = $post_cat;
		}
		
		$parent_cat = array();
		
		foreach ($post_cats as $post_cat) {
			$arg_tax = $tax_name;
			$cats = get_term_by('name', $post_cat, $arg_tax);
			
			if (empty($cats)) {
				$term_id = wp_insert_term($post_cat, $tax_name, $parent_cat);
				if (!is_wp_error($term_id)) {
					$post_category[] = $term_id['term_id'];
														
					if (!empty($post_tax_parent_statuses[$post_meta_index])) 
					{
						$parent_cat = array('parent' => $term_id['term_id']);
					}
					$this->write_log($post_cat . " added to categories");
				} else {
					$this->write_log("$post_cat can not be added as " . $tax_name . ": " . $term_id->get_error_message());
				}
				
			} else {
				$post_category[] = $cats->term_id;
				if (!empty($post_tax_parent_statuses[$post_meta_index])) 
				{
					wp_update_term($cats->term_id, $tax_name, $parent_cat);
					$parent_cat = array('parent' => $cats->term_id);									
				}
			}
		}
	}
	$post_meta_index++;
}