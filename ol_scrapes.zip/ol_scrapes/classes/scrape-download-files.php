<?php

/** no direct access **/
if (!defined('ABSPATH'))
	exit;

foreach($meta_downloads as $key => $value)
{
	$file_url = $meta_input[$key] == $value ? $value : $meta_input[$key];
	$attach_id = $this->image_fn->add_attachment_from_url($file_url, $new_id);
	
	if( $attach_id )
	{
		$attach_url = wp_get_attachment_url($attach_id);			
		update_post_meta($new_id, $key, $attach_url);
	}
}